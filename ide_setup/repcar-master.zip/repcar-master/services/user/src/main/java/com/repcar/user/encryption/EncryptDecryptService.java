/*
 * Copyright RepCar AD 2017
 */
package com.repcar.user.encryption;

public interface EncryptDecryptService {

    String encrypt(String password);
}
