/*
 * Copyright RepCar AD 2017
 */
package com.repcar.security.encryption;

public interface DecryptService {

    String decrypt(String password);

}